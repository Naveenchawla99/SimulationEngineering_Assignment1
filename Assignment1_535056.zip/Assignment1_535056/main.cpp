#include <iostream>
#include <cmath>

using namespace std;

int main() {
  // Set simulation parameters
  const double lyy = 3800;  // kgm^2
  const double sim_time = 10;  // seconds
  const double dt = 0.01;  // seconds, 

  // Set initial state
  double r = 0;  // rad
  double adot = 0;  // rad/s, initial yaw rate

  // Set input signal
  double ty = 0;

  // Run simulation
  for (double t = 0; t <= sim_time; t += dt) {
    // Calculate torque and update state
    double torque = ty;
    adot += torque / lyy * dt;
    r += adot * dt;

    // Output results
    cout << "Time: " << t << "s, Yaw: " << r << "rad, Yaw Rate: " << adot << "rad/s\n";
  }

  return 0;
}
